# Version 1.8.4 (10820)
- added usage of "user_tokens"
Resolves "Seems like there are some problems with connection to Facebook" issue.
