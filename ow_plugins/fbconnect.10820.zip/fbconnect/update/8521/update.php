<?php

Updater::getConfigService()->deleteConfig("fbconnect", "allow_synchronize");