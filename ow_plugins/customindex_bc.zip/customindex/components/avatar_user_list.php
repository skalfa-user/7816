<?php

/**
 * User list
 */
class CUSTOMINDEX_CMP_AvatarUserList extends BASE_CMP_AvatarUserList
{
}
